          Oracle Spatial GeoRaster Tools (Viewer and ETL)

1. Introduction

This file contains instructions for running the GeoRaster tools
for visualization and ETL (Extract Transform and Load) operations.

1.1. Visualization with the GeoRasterTool

The GeoRasterTool is a pure java standalone desktop application that
display image from Oracle GeoRaster objects in the database and from
images in the local file system. It can also display a virtual mosaic
defined as one or a list of GeoRaster tables or views. Additionally, it
provides the following features:

1) displaying cell values of GeoRaster object by a separate panel
2) displaying and configuring layers mapping by a separate panel
3) enabling/disabling block line and setting color of block line
4) supporting the following "view" actions by menu, toolbar or mouse
    Overview
    Zoom in
    Zoom out
    Refresh
5) supporting the following "image" actions by menu or toolbar
    automatic linear stretch
    manual linear stretch
    piecewise linear stretch
    normalize
    equalize
    brightness control
    contrast control
    threshold
6) providing GUI interfaces to allow users to use the JAI-based loader and 
   exporter to load into and export from GeoRaster objects.
7) supporting box selection on the GeoRaster object in the image panel,
   and allowing user to use the JAI-based exporter to export the selected
  �window to the image file in the local file system.
8) providing user interfaces to automatically execute some functions 
   from the GeoRaster PL/SQL package in the database
9) invoking the GeoRaster ETL tool from the main menu


1.2. Loader and Exporter based on JAI

The GeoRaster JAI-based loader and exporter are lightweight tools for 
conveniently load and export a limited number of image and raster files 
one at a time. It supports only several standard image formats.

The GeoRaster JAI-based loader and exporter is a legacy solution which 
has very limited capabilities. Using the GeorasterETL instead is recommended.

Refers to the file (georaster_jai_based_tools.txt) for more information
on how to use the GeoRaster JAI-based Loader and Exporter.


1.3. GeoRasterETL - ETL tool based on GDAL

The GeoRasterETL is also a standalone desktop application that uses GDAL
(Geospatial Data Abstrat Library, www.gdal.org) in order to support a
very large number of raster formats, including Oracle Spatial GeoRaster.

This GeoRasterETL provides a wizard to help automatically create XML
batch scripts files to load and export large volume of raster data
concurrently into and from Oracle GeoRaster objects in the database.

It can be either launched standalone or from the GeoRasterTool (Viewer).

Refer to the User's Guide for details (georaster_etl_user_guide.pdf).


2. Configuration

The GeoRasterETL requires setup GDAL before launching the application.

The GeoRasterTool does not depend on GDAL and can be used without
previous configuration.

However, the GeoRasterTool is fully integrated with GeoRasterETL, meaning
that the GeoRasterETL can be launched from GeoRasterTool main menu. In
order to use that feature GDAL needs to be setup first.


2.1 Setuping GDAL

In this folder we provide the script to prepare environment variables
required by GDAL on user's command line section and for the use of
GeoRasterETL. Follow these instructions to run the GDAL setup script:

On Windows, execute the command:

  % setup_gdal.bat

On Linux, execute the command:

  % source setup_gdal.conf

Test if GDAL is working by running the command line tools:

  % gdalinfo --version
  % gdalinfo --format georaster


3. Launching the applications

3.1. Launching the GeoRasterTool (Viewer)

On Windows, execute the command:

  % startGeoRasterTool.bat

On Linux, execute the commands:

  % sh startGeoRasterTool.sh


3.2. Launching GeoRasterETL

On Windows, execute the commands:

  % startGeoRasterETL.bat

On Linux, execute the commands:

  % sh startGeoRasterETL.sh

Note: GeoRasterETL can also be launched from GeoRasterTool main menu.


4. Migrating to a client machine

In order to migrate the GeoRaster tools to a client machine you should copy
the content of this folder to a folder accessible by the client machine.

In order to launch the GeoRasterTool application on the client machine
follows the same instruction explained on 3.1.

The GeoRasterETL requires GDAL and Oracle OCI libraries present on the
client system.

Oracle OCI libraries are available on Oracle Instant Client at OTN website
and GDAL pre-built zipped packages are available at ORACLE_HOME/md/gdal

Change the variable GDAL_HOME on the GDAL setup script according to the path
where GDAL is installed (unzipped) and follow the instructions on 3.2. on
how to launch GeoRasterETL.
