/
/ $Header: README.txt 09-jun-2011.07:56:30 begeorge Exp $
/
/ README.txt
/
/ Copyright (c) 2011, Oracle. All Rights Reserved.
/
/   NAME
/     README.txt - <one-line expansion of the name>
/
/   DESCRIPTION
/     <short description of component this file declares/defines>
/
/   NOTES
/     <other useful comments, qualifications, etc.>
/
/   MODIFIED   (MM/DD/YY)
/   begeorge    06/09/11 - Creation
/
This directory contains the scripts to load the transit information in
General Transit Feed Specification (GTFS) format into Oracle SQL table.
