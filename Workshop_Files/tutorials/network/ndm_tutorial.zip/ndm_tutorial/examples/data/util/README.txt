/
/ $Header: sdo/demo/network/examples/data/util/README.txt /main/1 2012/03/08 05:58:44 begeorge Exp $
/
/ README.txt
/
/ Copyright (c) 2012, Oracle. All Rights Reserved.
/
/   NAME
/     README.txt - <one-line expansion of the name>
/
/   DESCRIPTION
/     <short description of component this file declares/defines>
/
/   NOTES
/     <other useful comments, qualifications, etc.>
/
/   MODIFIED   (MM/DD/YY)
/   begeorge    03/07/12 - Creation
/
This directory has sub-directories each of which has data set up scripts for a
utility network

