/
/ README.txt
/
/ Copyright (c) 2007, Oracle. All Rights Reserved.
/

This folder contains sample java programs for the Network Data Model (NDM)
In-Memory API.
