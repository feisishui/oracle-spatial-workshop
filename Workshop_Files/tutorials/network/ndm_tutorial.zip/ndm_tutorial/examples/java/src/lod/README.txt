/
/ README.txt
/
/ Copyright (c) 2007, Oracle. All Rights Reserved.
/
This folder contains sample java programs for Network Data Model (NDM)
Load-On-Demand (LOD) API.
